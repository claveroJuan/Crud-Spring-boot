package com.ciisa.service;

import com.ciisa.model.Paciente;

public interface IPacienteService extends ICRUD<Paciente>{

}
