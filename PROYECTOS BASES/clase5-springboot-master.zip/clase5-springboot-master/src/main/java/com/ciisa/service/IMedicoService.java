package com.ciisa.service;

import com.ciisa.model.Medico;

public interface IMedicoService extends ICRUD<Medico>{

}
