package com.ciisa.service;

import com.ciisa.model.Examen;

public interface IExamenService extends ICRUD<Examen>{

}
