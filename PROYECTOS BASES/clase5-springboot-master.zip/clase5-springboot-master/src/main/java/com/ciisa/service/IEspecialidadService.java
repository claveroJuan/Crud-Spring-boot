package com.ciisa.service;

import com.ciisa.model.Especialidad;

public interface IEspecialidadService extends ICRUD<Especialidad>{

}
