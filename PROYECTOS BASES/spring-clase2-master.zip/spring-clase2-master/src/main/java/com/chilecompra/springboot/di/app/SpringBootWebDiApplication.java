package com.chilecompra.springboot.di.app;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringBootWebDiApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpringBootWebDiApplication.class, args);
	}

}
