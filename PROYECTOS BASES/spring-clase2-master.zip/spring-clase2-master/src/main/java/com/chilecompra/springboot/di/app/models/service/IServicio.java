package com.chilecompra.springboot.di.app.models.service;

public interface IServicio {
	
	public String operacion();

}
