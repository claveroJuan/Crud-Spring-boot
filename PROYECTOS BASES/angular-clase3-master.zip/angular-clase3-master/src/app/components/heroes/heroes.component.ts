import { Component, OnInit } from '@angular/core';
//aqui importamos el servicio, por lo cual al crear una variable tipo servicio lo podemos utilizar
import {HeroesService, Heroe} from '../../servicios/heroes.service';
import {Router} from '@angular/router';

@Component({
  selector: 'app-heroes',
  templateUrl: './heroes.component.html'
})
export class HeroesComponent implements OnInit {

  heroes:Heroe[] = []

  //aqui como ya lo importamos arriba, podemos definir una variable para poder utilizarla dentro de esta clase
  constructor(private _heroesService:HeroesService,
              private router:Router) { }

  //este metodo sirve para trabajar con operaciones complejas, servicios, observables, flechas, detectara
  //en este caso servicios
  ngOnInit() {
    this.heroes = this._heroesService.getHeroes(); //aqui estoy utlizando un metodo prestado de la clase service
    //console.log(this.heroes);
  }

  verHeroe(idx:number){
    this.router.navigate(['/heroe', idx]);
    //console.log(idx);
  }




}
